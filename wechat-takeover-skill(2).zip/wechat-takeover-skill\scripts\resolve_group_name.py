"""找出群号对应的界面显示名：对比 UI 会话列表元素与数据库会话摘要。"""
import wxenv  # noqa: F401

from wechatauto import WeChatDB
from wechatauto.uia_driver import WeChatUIA
from wechatauto.ui.main import WeChatMainWnd

db = WeChatDB()
uia = WeChatUIA()
if not uia.is_materialized():
    uia.ensure_materialized(timeout=15.0, force=True)
win = uia._find_main()
print("主窗口:", win.ClassName if win else None)

mw = WeChatMainWnd(hwnd=win.NativeWindowHandle)
print("\n--- 界面会话列表元素 ---")
for el in mw._session_api.get_session():
    try:
        texts = el.texts
    except Exception as exc:  # noqa: BLE001
        texts = "err:%s" % exc
    print("  name=%-24r texts=%r" % (el.name, texts))

print("\n--- 数据库会话（username | summary） ---")
for s in db.get_sessions(limit=25):
    print("  %-30s | %r" % (s.get("username"), (s.get("summary") or "")[:45]))

print("\n--- get_nickname(群号) ---")
for uid in ("54391644533@chatroom",):
    try:
        print("  %s -> %r" % (uid, db.get_nickname(uid)))
    except Exception as exc:  # noqa: BLE001
        print("  %s -> err %s" % (uid, exc))
    try:
        print("  group_id_to_name -> %r" % db.group_id_to_name(uid))
    except Exception as exc:  # noqa: BLE001
        print("  group_id_to_name -> err %s" % exc)
