"""引导 wx4py 运行环境：挂载 .tools/pylibs 及其 pywin32 子目录与 DLL 目录。

任何脚本在使用 wx4py 前先 `import wxenv` 即可。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LIBS = os.path.join(HERE, "pylibs")

for _p in (
    LIBS,
    os.path.join(LIBS, "win32"),
    os.path.join(LIBS, "win32", "lib"),
    os.path.join(LIBS, "Pythonwin"),
):
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

_DLL = os.path.join(LIBS, "pywin32_system32")
if os.path.isdir(_DLL):
    os.environ["PATH"] = _DLL + os.pathsep + os.environ.get("PATH", "")
    try:
        os.add_dll_directory(_DLL)
    except Exception:  # noqa: BLE001 - older Python or non-Windows
        pass
