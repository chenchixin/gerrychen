"""微信接管操作工具（安全封装）。

设计要点：
  * 任何界面操作前自动热激活控件树（应对「重启/重登后字节归零」）；
  * 发送后一律从本地数据库**回读验证**，不用库自带 verify（已知会误报）；
  * 批量发送默认只预览（dry-run），必须显式加 --send 才真的发；
  * 目标之间自动加延迟，避免高频触发风控。

用法：
  python .tools\\wxops.py sessions
  python .tools\\wxops.py export 文件传输助手 --limit 200
  python .tools\\wxops.py send --to 文件传输助手 --text "你好"
  python .tools\\wxops.py send --to 文件传输助手 --file D:\\a.pdf
  python .tools\\wxops.py broadcast --targets "群A,群B" --text "通知"        # 预览
  python .tools\\wxops.py broadcast --targets "群A,群B" --text "通知" --send  # 实发
  python .tools\\wxops.py admin --chat 群A --mute on --pin on
  python .tools\\wxops.py watch --chats "群A,群B" --reply "收到：{text}" --only-at --at-name 接雾
"""
import argparse
import io
import os
import sys
import time

import wxenv  # noqa: F401  (必须最先导入：挂载本地库与 DLL 路径)

from wechatauto import WeChatDB  # noqa: E402
from wechatauto.cli import resolve_chat  # noqa: E402


# ---------------------------------------------------------------- 基础设施

def get_db():
    return WeChatDB()


ALLOW_OCR_FALLBACK = False


def verify_wechat_window():
    """严格识别微信主窗口：必须是 Qt 窗口类，且所属进程确实是 Weixin.exe / WeChat.exe。

    只按窗口标题含「微信」来认窗口是危险的——DSH 自己的界面标题里就含「微信」，
    会被库的兜底逻辑误判成微信窗口，把文字打进错误的窗口。这里必须双重校验。
    """
    import psutil
    import win32gui
    import win32process

    found = []

    def cb(hwnd, acc):
        if win32gui.IsWindowVisible(hwnd):
            cls = win32gui.GetClassName(hwnd) or ""
            if cls.startswith("Qt") or cls.startswith("mmui::"):
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                try:
                    pname = (psutil.Process(pid).name() or "").lower()
                except Exception:  # noqa: BLE001
                    pname = ""
                if pname in ("weixin.exe", "wechat.exe"):
                    acc.append({"hwnd": hwnd, "pid": pid, "class": cls,
                                "title": win32gui.GetWindowText(hwnd)})
        return True

    win32gui.EnumWindows(cb, found)
    return found


def ensure_tree(timeout=20.0, allow_fallback=None) -> bool:
    """确保控件树已物化。

    allow_fallback=False（默认）时：目标窗口不可信或控件树拿不到就中止，
    绝不退化成「按标题猜窗口」——那条路会把文字打进 DSH 自己的界面窗口。
    """
    if allow_fallback is None:
        allow_fallback = ALLOW_OCR_FALLBACK
    wins = verify_wechat_window()
    if not wins:
        print("[安全检查] 没有找到真正的微信主窗口（Qt 类 + Weixin.exe 进程），中止。")
        return False
    win = wins[0]
    print("[安全检查] 微信主窗口 hwnd=%s pid=%s class=%s title=%r"
          % (win["hwnd"], win["pid"], win["class"], win["title"]), flush=True)

    # 库在每次发送成功后会最小化微信窗口，而最小化时 UIA 扫不到子控件，
    # 会被误判成「控件树没了」并触发一次注定失败的重新热写。先恢复窗口。
    import win32con
    import win32gui as _wg

    if _wg.IsIconic(win["hwnd"]):
        _wg.ShowWindow(win["hwnd"], win32con.SW_RESTORE)
        print("[环境] 微信窗口原为最小化，已恢复", flush=True)
        time.sleep(1.0)
    try:
        _wg.SetForegroundWindow(win["hwnd"])
    except Exception:  # noqa: BLE001
        pass

    from wechatauto.uia_driver import WeChatUIA

    uia = WeChatUIA()
    if uia.is_materialized():
        print("[环境] 控件树已物化", flush=True)
        return True
    ok = uia.ensure_materialized(timeout=timeout, force=True)
    print("[环境] 热激活控件树 -> %s" % ok, flush=True)
    if ok:
        return True
    if allow_fallback:
        print("[警告] 控件树不可用，将退化为 OCR/坐标路径（窗口必须前台，可靠性下降）。")
        return True
    print("[中止] 控件树无法物化。为安全起见不执行界面操作。\n"
          "        请先解决模块枚举被拒的问题（见 微信接管手册 §故障排查），"
          "或显式加 --allow-ocr-fallback 承担风险。")
    return False


def _msg_key(m):
    return (m.get("local_id"), m.get("create_time"), (m.get("content") or "")[:120])


def latest_key(db, user):
    rows = db.get_messages(user, limit=1) or []
    return _msg_key(rows[0]) if rows else None


def wait_new_message(db, user, before, tries=10, interval=1.5):
    """等一条比 before 更新的消息出现（对任何消息类型都适用）。"""
    for _ in range(tries):
        rows = db.get_messages(user, limit=3) or []
        if rows and _msg_key(rows[0]) != before:
            return True, rows[0]
        time.sleep(interval)
    return False, None


_UI_SESSIONS = {"elements": None}


def _ui_session_elements(refresh=False):
    """读取界面会话列表（带缓存：构建一次 WeChatMainWnd 较慢，避免每条消息都重建）。"""
    if _UI_SESSIONS["elements"] is not None and not refresh:
        return _UI_SESSIONS["elements"]
    try:
        from wechatauto.ui.main import WeChatMainWnd
        from wechatauto.uia_driver import WeChatUIA

        uia = WeChatUIA()
        if not uia.is_materialized():
            uia.ensure_materialized(timeout=15.0, force=True)
        win = uia._find_main()
        if win is None:
            return []
        mw = WeChatMainWnd(hwnd=win.NativeWindowHandle)
        elements = mw._session_api.get_session()
        _UI_SESSIONS["elements"] = elements
        return elements
    except Exception:  # noqa: BLE001
        return []


def resolve_display_name(db, username: str) -> str:
    """把会话 username 解析成**界面上显示的会话名**。

    微信搜索框只认显示名。没有自定义群名的群，数据库里只有群号
    （如 ``54391644533@chatroom``），``get_nickname`` 解析不出来 —— 拿群号去搜
    索框必然命中不了，会一路重试到卡死。这类群在界面上按成员名显示
    （如「陈刚、陈新」），只能靠界面会话列表反查：

      用数据库里该会话的最新消息摘要，去比对界面会话条目的预览文本
      （界面会在预览前加「发送人: 」前缀），命中即取该条目的显示名。
    """
    if not username:
        return ""
    if username == "filehelper":
        return "文件传输助手"
    try:
        nick = db.get_nickname(username) or ""
    except Exception:  # noqa: BLE001
        nick = ""
    if nick and nick != username and not nick.endswith("@chatroom"):
        return nick

    # 回退：摘要匹配界面会话列表
    try:
        summary = ""
        for s in db.get_sessions(limit=60):
            if s.get("username") == username:
                summary = (s.get("summary") or "").strip()
                break
        if not summary:
            return ""

        for el in _ui_session_elements():
            texts = [str(t or "").strip() for t in (getattr(el, "texts", []) or [])]
            for t in texts[1:]:          # 第一项就是名字本身，跳过
                if t.endswith(summary) or t == summary:
                    return el.name
    except Exception:  # noqa: BLE001
        pass
    return ""


def resolve_username(db, name: str) -> str:
    """把界面显示名反查成会话 username（群没有自定义名时数据库里只有群号）。

    发送后要按 username 去数据库回读验证；直接用显示名会查不到，导致误报失败。
    """
    name = (name or "").strip()
    if not name:
        return ""
    if name == "文件传输助手":
        return "filehelper"
    for s in db.get_sessions(limit=80):
        uid = s.get("username") or ""
        if not uid:
            continue
        if uid == name:
            return uid
        try:
            if (db.get_nickname(uid) or "") == name:
                return uid
        except Exception:  # noqa: BLE001
            pass
        if resolve_display_name(db, uid) == name:
            return uid
    return ""


# ---------------------------------------------------------------- 各子命令

def cmd_sessions(args):
    db = get_db()
    rows = db.get_sessions(limit=args.limit)
    for s in rows:
        try:
            name = db.get_nickname(s["username"]) or s["username"]
        except Exception:  # noqa: BLE001
            name = s["username"]
        print("%-26s 未读 %-4s %s" % (name[:24], s.get("unread"),
                                      (s.get("summary") or "")[:42]))
    print("共 %d 个会话" % len(rows))
    return 0


def cmd_export(args):
    db = get_db()
    user, display = resolve_chat(db, args.chat)
    rows = list(reversed(db.get_messages(user, limit=args.limit) or []))
    out = args.out or "%s_%s.txt" % (display or user, time.strftime("%Y%m%d_%H%M"))
    own = getattr(db, "wxid", "") or ""
    with io.open(out, "w", encoding="utf-8") as fh:
        fh.write("# 会话: %s (%s)\n" % (display or user, user))
        fh.write("# 导出时间: %s\n# 条数: %d\n\n"
                 % (time.strftime("%Y-%m-%d %H:%M:%S"), len(rows)))
        for m in rows:
            ts = time.strftime("%Y-%m-%d %H:%M:%S",
                               time.localtime(m.get("create_time") or 0))
            sender = "" if m.get("sender_username") == own else (m.get("sender_username") or "")
            tag = "" if m.get("type") == "text" else "[%s]" % m.get("type")
            fh.write("[%s] %s%s%s\n" % (ts, (sender + ": ") if sender else "",
                                        tag, (m.get("content") or "").replace("\n", " ")))
    print("已导出 %d 条 -> %s" % (len(rows), os.path.abspath(out)))
    return 0


def _grab_box_pixels(gui, box):
    """抓取输入框区域的灰度像素，用于判断粘贴后内容是否真的变了。"""
    try:
        rel = (box[0] + 5, box[1], box[2] - 5, box[3])
        img = gui._grab_screen(gui._rel_to_screen(rel))
        return img.convert("L").tobytes()
    except Exception:  # noqa: BLE001
        return None


def _pixel_diff_ratio(a, b):
    if not a or not b or len(a) != len(b):
        return 1.0
    step = max(1, len(a) // 5000)
    total = changed = 0
    for i in range(0, len(a), step):
        total += 1
        if abs(a[i] - b[i]) > 25:
            changed += 1
    return changed / max(1, total)


def send_file_verified(target: str, path: str, tries: int = 3):
    """带**附件草稿校验**的文件发送，替代库自带的 send_file。

    库自带的 ``_paste_attachment_and_send`` 对非图片文件不检测草稿：粘贴失败也会
    等 2 秒后盲按回车并返回 True（本机实测过「报告文件已发送但数据库没有任何文件消息」）。
    这里改成：粘贴后比对输入框区域像素变化 / 输入区是否向上扩展，**确认到草稿才按回车**，
    否则清空重试；多次失败就如实返回失败，绝不空按回车。

    返回 (ok, 说明)。
    """
    from wechatauto.guia import VK_A, VK_DELETE, VK_RETURN, VK_V, WeChatGUI

    gui = WeChatGUI()
    if not gui.ensure_visible():
        return False, "微信窗口不可见（可能锁屏/会话断开）"
    if not gui._open_chat_and_settle(target):
        return False, "打不开会话：%s" % target
    box = gui.get_input_box()
    if not box:
        return False, "探测不到输入框"
    gui.focus_input(box)
    time.sleep(0.6)
    base = _grab_box_pixels(gui, box)

    for attempt in range(1, tries + 1):
        if not gui.copy_files_to_clipboard([path]):
            return False, "拷贝文件到剪贴板失败"
        time.sleep(0.5)
        gui._input.key(VK_A, ctrl=True)
        gui._input.key(VK_DELETE)
        gui._input.key(VK_V, ctrl=True)
        time.sleep(2.5)

        ratio = _pixel_diff_ratio(base, _grab_box_pixels(gui, box))
        # 文件卡片是浅灰底，灰度差很小（实测 <25），只靠像素差会漏检；
        # 但卡片上的文件图标是彩色的，所以复用库里的「彩色草稿」检测
        # （它扫的是输入框上方一段区域，正好覆盖卡片位置）。
        try:
            colored = gui._input_box_has_color_draft(box, wait=5.0)
        except Exception:  # noqa: BLE001
            colored = False
        print("     粘贴尝试 %d：变化率=%.2f，检测到彩色附件图标=%s"
              % (attempt, ratio, "是" if colored else "否"), flush=True)

        if colored or ratio > 0.30:
            gui._input.key(VK_RETURN)
            time.sleep(1.5)
            return True, "已确认附件草稿并回车（变化率 %.2f）" % ratio

        # 没有草稿：清空重来，绝不盲按回车
        gui._input.key(VK_A, ctrl=True)
        gui._input.key(VK_DELETE)
        time.sleep(0.8)

    return False, ("连续 %d 次粘贴后输入区都没出现附件草稿，"
                   "已放弃且没有按回车（不会误发空消息）" % tries)


def _do_send(db, to, text=None, file=None, image=None, delay=1.5):
    """对单个目标执行一次发送，并做数据库回读验证。返回 (ok, 说明)。"""
    from wechatauto.guia import quick_send, quick_send_file, quick_send_image

    user, display = resolve_chat(db, to)
    target = display or user
    # 群没有自定义名时 resolve_chat 只能拿到显示名，回读验证必须换成群号
    verify_user = resolve_username(db, target) or user
    before = latest_key(db, verify_user)
    print("  -> 目标 %s (库内 %s)" % (target, verify_user), flush=True)

    if image:
        r = quick_send_image(image, target)
    elif file:
        draft_ok, draft_detail = send_file_verified(target, file)
        print("     附件草稿校验: %s" % draft_detail, flush=True)
        if not draft_ok:
            return False, draft_detail
        r = "（文件走自带草稿校验的发送路径）"
        if text:
            time.sleep(delay)
            quick_send(text, target)
    else:
        r = quick_send(text, target)
    print("     界面返回: %s" % (r,), flush=True)

    ok, msg = wait_new_message(db, verify_user, before)
    if not ok:
        return False, "数据库未确认（可能发送失败，也可能写入延迟；稍后用 export 复查）"

    content = (msg.get("content") or "")[:60]
    if text and not file and not image and text not in (msg.get("content") or ""):
        return False, "有新消息但不是本次内容：%s" % content
    if file and os.path.basename(file) not in (msg.get("content") or ""):
        return True, "已确认新消息（文件消息内容不含文件名属正常）：%s" % content
    return True, "数据库已确认：%s" % content


def cmd_send(args):
    db = get_db()
    if not (args.text or args.file or args.image):
        print("要发什么？--text / --file / --image"); return 2
    if not ensure_tree():
        print("控件树激活失败，中止"); return 1
    ok, detail = _do_send(db, args.to, args.text, args.file, args.image, args.delay)
    print("%s  %s" % ("成功：" if ok else "失败：", detail))
    return 0 if ok else 1


def cmd_broadcast(args):
    targets = [t.strip() for t in args.targets.split(",") if t.strip()]
    if not targets:
        print("--targets 为空"); return 2
    print("=== %s ===" % ("预览（未发送）" if not args.send else "实发模式"))
    print("目标 %d 个：%s" % (len(targets), "、".join(targets)))
    print("内容：%s" % (args.text or ""))
    if args.file:
        print("附件：%s" % args.file)
    if not args.send:
        print("\n确认无误后，追加 --send 参数才会真正发送。")
        return 0

    db = get_db()
    if not ensure_tree():
        print("控件树激活失败，中止"); return 1
    results = []
    for i, t in enumerate(targets, 1):
        print("\n[%d/%d] %s" % (i, len(targets), t), flush=True)
        try:
            ok, detail = _do_send(db, t, args.text, args.file, None, args.delay)
        except Exception as exc:  # noqa: BLE001
            ok, detail = False, "%s: %s" % (type(exc).__name__, exc)
        results.append((t, ok, detail))
        if i < len(targets):
            time.sleep(args.delay)

    print("\n=== 汇总 ===")
    for t, ok, detail in results:
        print("%-24s %s  %s" % (t[:22], "成功" if ok else "失败", detail))
    fail = sum(1 for _t, ok, _d in results if not ok)
    print("共 %d 个目标，成功 %d，失败 %d" % (len(results), len(results) - fail, fail))
    return 0 if fail == 0 else 1


def cmd_admin(args):
    if not ensure_tree():
        print("控件树激活失败，中止"); return 1
    from wechatauto.ui.main import WeChatMainWnd
    from wechatauto.uia_driver import WeChatUIA

    uia = WeChatUIA()
    win = uia._find_main()
    if win is None:
        print("找不到主窗口"); return 1
    mw = WeChatMainWnd(hwnd=win.NativeWindowHandle)
    elements = mw._session_api.get_session()

    target = None
    for el in elements:
        if el.name == args.chat:
            target = el
            break
    if target is None:
        print("会话列表里没找到「%s」。当前可见：%s"
              % (args.chat, "、".join(el.name for el in elements[:15])))
        return 1

    if args.mute == "on":
        # 库的 toggle_mute() 是单向的（且没有「取消消息免打扰」语言键），
        # 这里直接点原始菜单项，才能可靠地开关。
        print("开启免打扰 ->", target.select_option("消息免打扰"))
    elif args.mute == "off":
        print("关闭免打扰 ->", target.select_option("取消消息免打扰"))
    if args.pin == "on":
        print("置顶 ->", target.pin())
    elif args.pin == "off":
        print("取消置顶 ->", target.unpin())
    if not args.mute and not args.pin:
        print("没有指定动作（--mute on/off --pin on/off）")
    return 0


def cmd_watch(args):
    if not ensure_tree():
        print("控件树激活失败，中止"); return 1
    from wechatauto import WeChat

    chats = [c.strip() for c in (args.chats or "").split(",") if c.strip()]
    if not chats and not args.all:
        print('要么给 --chats "群A,群B"，要么加 --all 监听全部会话')
        return 2
    at_name = args.at_name or ""
    template = args.reply or ""
    recent_replies = []  # 我最近发出的自动回复内容（回声守卫：按内容比对，不依赖会话键）
    last_reply_at = {}   # 会话 -> 上一次回复时间（频率守卫）

    def make_cb():
        def cb(msg, chat):
            name = (getattr(chat, "nickname", "") or getattr(chat, "who", "") or "?")
            content = (getattr(msg, "content", "") or "").strip()
            sender = getattr(msg, "sender", "") or ""
            # 库不会过滤自己的消息，必须自己挡：否则自动回复会自己触发自己
            is_self = (bool(getattr(msg, "is_self", False))
                       or getattr(msg, "attr", "") == "self")
            stamp = time.strftime("%H:%M:%S")
            # 文件/图片消息的 content 是整段 XML，日志里截断显示（判定仍用完整内容）
            shown = content.replace("\n", " ")
            if len(shown) > 80:
                shown = shown[:80] + "…（%d 字符）" % len(content)
            print("[%s] %s | %s: %s%s" % (stamp, name, sender, shown,
                                          "   (自己发的，忽略)" if is_self else ""),
                  flush=True)
            if is_self:
                return
            if not template:
                return
            # 回声守卫：本机库里「自己发的」sender_id 是 1，而库硬编码按 2 判断，
            # 所以它把自己发的消息全当成别人发的 —— 不能只信 is_self。
            # 自己刚发出的回复若又回流进来，内容必然完全一致，直接忽略。
            if content and content in recent_replies:
                print("     (自己的回复回流，已忽略)", flush=True)
                return
            # 频率守卫：同一会话两次回复至少间隔 --min-interval 秒，防止任何意外连发
            if time.time() - last_reply_at.get(name, 0) < args.min_interval:
                print("     (距上次回复过近，跳过)", flush=True)
                return
            at_me = ("@" in content) and ((at_name and at_name in content)
                                          or "所有人" in content)
            if args.only_at and not at_me:
                return
            text = template.replace("{text}", content).replace("{sender}", sender)
            # 长期运行的最后一个安全闸：发送前再次确认目标窗口与控件树可用。
            # 若微信重启过（网关字节归零、而本机模块枚举被拒无法热写），
            # 这里会失败并放弃回复，而不是退化成 OCR 路径去猜窗口、误发到别处。
            if not ensure_tree(timeout=8.0):
                print("     (控件树不可用，已放弃本次回复以免误发)", flush=True)
                return
            # 关键修复：库给的 chat 常常以「群号/wxid」为名（群没有自定义名时解析不出
            # 显示名），拿群号去微信搜索框必然命中不了，会一路重试到卡死。
            # 必须先换成界面显示名再发。群内文本里带上发送人，便于对方识别。
            who = getattr(chat, "who", "") or getattr(chat, "nickname", "") or ""
            target = resolve_display_name(get_db(), who)
            if not target:
                print("     (拿不到「%s」的界面显示名，放弃回复以免卡死)" % who, flush=True)
                return
            try:
                from wechatauto.guia import quick_send
                res = quick_send(text, target)
                recent_replies.append(text.strip())
                del recent_replies[:-20]
                last_reply_at[name] = time.time()
                print("     已回复 -> %s : %s" % (target, res), flush=True)
            except Exception as exc:  # noqa: BLE001
                print("     回复失败：%s" % exc, flush=True)
        return cb

    wx = WeChat()
    if args.all:
        print("注册监听：全部会话（含自动发现的新会话） -> %s"
              % (wx.AddListenAll(make_cb()),), flush=True)
    else:
        for name in chats:
            print("注册监听：%s -> %s" % (name, wx.AddListenChat(name, make_cb())),
                  flush=True)
    wx.StartListening()
    print("\n开始监听（%s）。按 Ctrl+C 退出。"
          % ("仅被 @ 时回复" if args.only_at else "每条都回复"), flush=True)
    try:
        wx.KeepRunning()
    except KeyboardInterrupt:
        wx.StopListening()
        print("\n已停止监听")
    return 0


# ---------------------------------------------------------------- 入口

def main(argv=None):
    parser = argparse.ArgumentParser(description="微信接管操作工具")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("sessions", help="列出会话")
    p.add_argument("--limit", type=int, default=30)
    p.set_defaults(func=cmd_sessions)

    p = sub.add_parser("export", help="导出聊天记录为 UTF-8 文本")
    p.add_argument("chat")
    p.add_argument("--limit", type=int, default=500)
    p.add_argument("--out")
    p.set_defaults(func=cmd_export)

    p = sub.add_parser("send", help="发送文本/文件/图片并回读验证")
    p.add_argument("--to", required=True)
    p.add_argument("--text")
    p.add_argument("--file")
    p.add_argument("--image")
    p.add_argument("--delay", type=float, default=1.5)
    p.set_defaults(func=cmd_send)

    p = sub.add_parser("broadcast", help="群发（默认只预览，--send 才实发）")
    p.add_argument("--targets", required=True, help="逗号分隔")
    p.add_argument("--text")
    p.add_argument("--file")
    p.add_argument("--delay", type=float, default=2.0)
    p.add_argument("--send", action="store_true")
    p.set_defaults(func=cmd_broadcast)

    p = sub.add_parser("admin", help="置顶 / 免打扰")
    p.add_argument("--chat", required=True)
    p.add_argument("--mute", choices=["on", "off"], help="免打扰 开/关")
    p.add_argument("--pin", choices=["on", "off"])
    p.set_defaults(func=cmd_admin)

    p = sub.add_parser("watch", help="监听新消息，可按 @ 自动回复")
    p.add_argument("--chats", help="逗号分隔；与 --all 二选一")
    p.add_argument("--all", action="store_true", help="监听全部会话（自动发现新会话）")
    p.add_argument("--reply", help="回复模板，支持 {text} {sender}")
    p.add_argument("--only-at", action="store_true", default=True,
                   help="仅在被人@时回复（默认开启；这一模式本身不会自己触发自己）")
    p.add_argument("--reply-all", action="store_false", dest="only_at",
                   help="对每条消息都回复（有死循环风险，靠回声/频率守卫兜底）")
    p.add_argument("--min-interval", type=float, default=3.0,
                   help="同一会话两次回复的最小间隔秒数")
    p.add_argument("--at-name", help="你在该群的群昵称，用于判断是否被@")
    p.set_defaults(func=cmd_watch)

    parser.add_argument("--allow-ocr-fallback", action="store_true",
                        help="控件树不可用时允许退化为 OCR/坐标路径（有误发到错误窗口的风险）")
    args = parser.parse_args(argv)
    global ALLOW_OCR_FALLBACK
    ALLOW_OCR_FALLBACK = bool(args.allow_ocr_fallback)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
