"""诊断：剪贴板文件拷贝是否真的成功、微信窗口是否前台。"""
import time

import wxenv  # noqa: F401

import win32clipboard
import win32con
import win32gui
from wechatauto.guia import WeChatGUI

ZIP = r"D:\DSH工作空间\短视频制作\dist\wechat-takeover-skill.zip"

gui = WeChatGUI()
print("ensure_visible ->", gui.ensure_visible())
print("微信 hwnd =", gui.main_hwnd)
print("前台 hwnd =", win32gui.GetForegroundWindow())
print("窗口标题(前台) =", repr(win32gui.GetWindowText(win32gui.GetForegroundWindow())))
rect = win32gui.GetWindowRect(gui.main_hwnd)
print("微信窗口屏幕坐标 =", rect)

ok = gui.copy_files_to_clipboard([ZIP])
print("copy_files_to_clipboard ->", ok)
time.sleep(1.2)

win32clipboard.OpenClipboard()
try:
    fmt = win32clipboard.EnumClipboardFormats(0)
    formats = []
    while fmt:
        formats.append(fmt)
        fmt = win32clipboard.EnumClipboardFormats(fmt)
    print("剪贴板格式列表 =", formats)
    has_hdrop = bool(win32clipboard.IsClipboardFormatAvailable(win32con.CF_HDROP))
    print("CF_HDROP(15) 存在 =", has_hdrop)
    if has_hdrop:
        try:
            print("剪贴板文件 =", win32clipboard.GetClipboardData(win32con.CF_HDROP))
        except Exception as exc:  # noqa: BLE001
            print("读取文件列表失败:", exc)
finally:
    win32clipboard.CloseClipboard()
