"""查清「自己发的消息」在数据库行里的可靠判据。"""
import wxenv  # noqa: F401

from wechatauto import WeChatDB

db = WeChatDB()
own = db.get_self_info()
print("本人:", own)
rows = db.get_messages("filehelper", limit=5) or []
for r in rows:
    print("---")
    for k in ("local_id", "create_time", "type", "sender_id", "sender_username", "content"):
        v = r.get(k)
        if k == "content":
            v = (v or "")[:30]
        print("   %-16s = %r" % (k, v))
    print("   is_self(=sender_id==2) :", r.get("sender_id") == 2)
    print("   is_self(==own wxid)    :", str(r.get("sender_username")) == str(own.get("username")))
