"""在工作区内直接下载并解包 wheel（不依赖 pip 的临时目录/删除逻辑）。

用法: python install_wheels.py wx4py [更多包名...]
"""
import io
import json
import os
import sys
import urllib.request
import zipfile

from pip._vendor.packaging.markers import default_environment
from pip._vendor.packaging.requirements import Requirement

HERE = os.path.dirname(os.path.abspath(__file__))
WHEEL_DIR = os.path.join(HERE, "wheels")
LIB_DIR = os.path.join(HERE, "pylibs")

ENV = default_environment()
ENV.setdefault("extra", "")


def fetch_json(url):
    with urllib.request.urlopen(url, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def wheel_score(filename):
    """越大越优先；返回 None 表示不兼容（不是 wheel 或平台/版本不匹配）。"""
    if not filename.endswith(".whl"):
        return None
    stem = filename[:-4]
    parts = stem.split("-")
    if len(parts) < 5:
        return None
    pytag, abitag, platform = parts[-3], parts[-2], parts[-1]

    tags = pytag.split(".")
    want = (sys.version_info[0], sys.version_info[1])
    py_score = None
    if "py3" in tags:
        py_score = 0
    else:
        for t in tags:
            if not t.startswith("cp") or not t[2:].isdigit():
                continue
            digits = t[2:]
            major, minor = int(digits[0]), int(digits[1:])
            if (major, minor) == want:
                py_score = 3
                break
            # abi3 wheels stay compatible with every later Python 3 release.
            if abitag == "abi3" and (major, minor) <= want:
                py_score = max(py_score or 0, 1)
    if py_score is None:
        return None

    if platform == "any":
        plat_score = 5
    elif platform == "win_amd64":
        plat_score = 20
    elif platform == "win32":
        plat_score = 10
    else:
        return None

    if abitag == "none":
        abi_score = 0
    elif abitag == "abi3":
        abi_score = 3
    else:
        abi_score = 5

    return plat_score + py_score + abi_score


def pick_wheel(info):
    files = [f for f in info["urls"] if f["packagetype"] == "bdist_wheel"]
    best, best_score, best_file = None, -1, None
    for f in files:
        s = wheel_score(f["filename"])
        if s is not None and s > best_score:
            best, best_score, best_file = s, s, f
    return best_file


def install(name, specifier=""):
    info = fetch_json("https://pypi.org/pypi/%s/json" % name)["info"] if False else None
    data = fetch_json("https://pypi.org/pypi/%s/json" % name)
    info = data["info"]
    version = info["version"]
    if specifier:
        from pip._vendor.packaging.specifiers import SpecifierSet

        ss = SpecifierSet(specifier)
        # prereleases=None lets the specifier itself decide: a specifier that
        # names a prerelease (e.g. >=1.0.0b10) then accepts prerelease versions.
        candidates = [v for v in data["releases"] if ss.contains(v, prereleases=None)]
        if not candidates:
            raise RuntimeError("%s: no version satisfies %s" % (name, specifier))

        def key(v):
            return tuple(int(x) if x.isdigit() else 0 for x in v.split(".")[:4])

        version = sorted(candidates, key=key)[-1]
        data = fetch_json("https://pypi.org/pypi/%s/%s/json" % (name, version))
        info = data["info"]

    wheel = pick_wheel(data)
    if wheel is None:
        raise RuntimeError("%s %s: 没有适配当前 Python/平台的 wheel" % (name, version))

    os.makedirs(WHEEL_DIR, exist_ok=True)
    os.makedirs(LIB_DIR, exist_ok=True)
    dest = os.path.join(WHEEL_DIR, wheel["filename"])
    if not os.path.exists(dest):
        with urllib.request.urlopen(wheel["url"], timeout=120) as resp, open(dest, "wb") as fh:
            fh.write(resp.read())

    with zipfile.ZipFile(dest) as zf:
        zf.extractall(LIB_DIR)
        meta_name = [n for n in zf.namelist() if n.endswith(".dist-info/METADATA")][0]
        meta = zf.read(meta_name).decode("utf-8", "replace")

    print("INSTALLED %s %s -> %s" % (name, version, wheel["filename"]))

    deps = []
    for line in meta.splitlines():
        if not line.lower().startswith("requires-dist:"):
            continue
        raw = line.split(":", 1)[1].strip()
        try:
            req = Requirement(raw)
        except Exception as exc:  # noqa: BLE001
            print("  SKIP unparsable requirement %r (%s)" % (raw, exc))
            continue
        if req.marker is not None:
            env = dict(ENV)
            if "extra" in str(req.marker):
                continue
            try:
                if not req.marker.evaluate(env):
                    continue
            except Exception:  # noqa: BLE001
                continue
        deps.append((req.name, str(req.specifier)))
    return deps


def main():
    queue = [(a, "") for a in sys.argv[1:]]
    if not queue:
        print("usage: install_wheels.py <package> [...]")
        return 2
    seen = {}
    failures = []
    while queue:
        name, spec = queue.pop(0)
        key = name.lower().replace("_", "-")
        if key in seen:
            continue
        seen[key] = spec
        try:
            deps = install(name, spec)
        except Exception as exc:  # noqa: BLE001
            failures.append((name, repr(exc)))
            print("FAILED %s: %r" % (name, exc))
            continue
        for dep_name, dep_spec in deps:
            if dep_name.lower().replace("_", "-") not in seen:
                queue.append((dep_name, dep_spec))
    print("--- summary ---")
    print("installed:", sorted(seen))
    print("failures:", failures)
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
