"""诊断：能否打开微信进程、枚举其模块。判断是权限问题还是安全软件拦截。"""
import ctypes
from ctypes import wintypes

import wxenv  # noqa: F401

import psutil
import win32gui
import win32process

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

MASKS = [
    (0x1000, "QUERY_LIMITED_INFORMATION"),
    (0x0400, "QUERY_INFORMATION"),
    (0x0010, "VM_READ"),
    (0x0020, "VM_WRITE"),
    (0x0008, "VM_OPERATION"),
]


def integrity():
    """打印当前进程完整性级别。"""
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    TOKEN_QUERY = 0x0008
    TokenIntegrityLevel = 25
    h = wintypes.HANDLE()
    advapi.OpenProcessToken(kernel32.GetCurrentProcess(), TOKEN_QUERY, ctypes.byref(h))
    size = wintypes.DWORD()
    advapi.GetTokenInformation(h, TokenIntegrityLevel, None, 0, ctypes.byref(size))
    buf = ctypes.create_string_buffer(size.value)
    ok = advapi.GetTokenInformation(h, TokenIntegrityLevel, buf, size.value,
                                    ctypes.byref(size))
    if not ok:
        return "unknown"
    sid_ptr = ctypes.cast(buf, ctypes.POINTER(ctypes.c_void_p))[0]
    advapi.ConvertSidToStringSidW.restype = wintypes.BOOL
    strsid = wintypes.LPWSTR()
    advapi.ConvertSidToStringSidW(ctypes.c_void_p(sid_ptr), ctypes.byref(strsid))
    return strsid.value


print("本进程完整性级别 SID:", integrity())
print("(S-1-16-4096=低 / S-1-16-8192=中 / S-1-16-12288=高)")

# 微信主窗口所属进程
hwnd = win32gui.FindWindow("Qt51514QWindowIcon", None)
_, win_pid = win32process.GetWindowThreadProcessId(hwnd) if hwnd else (0, 0)
print("微信窗口 hwnd=%s pid=%s" % (hwnd, win_pid))

print("\n--- Weixin 进程与访问权限 ---")
for proc in psutil.process_iter(["pid", "name", "exe"]):
    name = (proc.info["name"] or "").lower()
    if "weixin" not in name and "wechat" not in name:
        continue
    pid = proc.info["pid"]
    flags = []
    handles = {}
    for mask, label in MASKS:
        h = kernel32.OpenProcess(mask, False, pid)
        handles[label] = h
        flags.append("%s=%s" % (label, "OK" if h else "DENIED"))
    line = "  pid=%-6s %-14s %s" % (pid, proc.info["name"], " ".join(flags))
    mark = "  <== 主窗口" if pid == win_pid else ""
    print(line + mark)

    h = handles.get("QUERY_INFORMATION") or handles.get("QUERY_LIMITED_INFORMATION")
    if h:
        arr = (ctypes.c_void_p * 1024)()
        need = wintypes.DWORD()
        LIST_MODULES_ALL = 0x03
        ok = psapi.EnumProcessModulesEx(ctypes.c_void_p(h), arr, ctypes.sizeof(arr),
                                        ctypes.byref(need), LIST_MODULES_ALL)
        if not ok:
            print("      EnumProcessModulesEx 失败 err=%s" % ctypes.get_last_error())
        else:
            cnt = need.value // ctypes.sizeof(ctypes.c_void_p)
            names = []
            buf = ctypes.create_unicode_buffer(512)
            for i in range(cnt):
                if psapi.GetModuleBaseNameW(ctypes.c_void_p(h), arr[i], buf, 512):
                    names.append(buf.value)
            weixin = [n for n in names if n.lower().startswith("weixin")]
            print("      模块数=%d  含 Weixin*.dll: %s" % (len(names), weixin or "无"))
        kernel32.CloseHandle(h)
    for label, h in handles.items():
        if h:
            kernel32.CloseHandle(h)
