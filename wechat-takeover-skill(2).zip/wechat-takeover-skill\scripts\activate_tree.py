"""热激活微信 Qt 无障碍网关，让 mmui:: 控件树物化，并报告结果。"""
import json
import logging
import sys

import wxenv  # noqa: F401

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

from wechatauto.uia_driver import WeChatUIA  # noqa: E402

uia = WeChatUIA()

print("--- before ---", flush=True)
hwnds = uia._wechat_hwnds()
print("wechat_hwnds:", hwnds, flush=True)
print("is_materialized:", uia.is_materialized(), flush=True)

ok = uia.ensure_materialized(timeout=15.0, force=True)
print("ensure_materialized ->", ok, flush=True)
print("is_materialized after:", uia.is_materialized(), flush=True)

print("--- describe_layout ---", flush=True)
try:
    print(json.dumps(uia.describe_layout(), ensure_ascii=False, indent=2), flush=True)
except Exception as exc:  # noqa: BLE001
    print("describe_layout failed:", type(exc).__name__, exc, flush=True)

sys.exit(0 if ok else 1)
