"""在微信窗口上直接枚举 UIA 控件树，确认 mmui:: 控件是否真的物化了。"""
import sys

import wxenv  # noqa: F401

import uiautomation as auto
import win32gui

hwnd = win32gui.FindWindow("Qt51514QWindowIcon", None)
print("hwnd =", hwnd, flush=True)
if not hwnd:
    sys.exit(1)

win = auto.ControlFromHandle(hwnd)
try:
    print("root class =", win.ClassName, "| name =", win.Name, flush=True)
except Exception as exc:  # noqa: BLE001
    print("root read failed:", exc, flush=True)

acc = []
LIMIT = 90


def walk(ctrl, depth=0, max_depth=8):
    if len(acc) >= LIMIT or depth > max_depth:
        return
    try:
        children = ctrl.GetChildren()
    except Exception:  # noqa: BLE001
        return
    for child in children:
        if len(acc) >= LIMIT:
            return
        try:
            cls = child.ClassName or ""
            name = (child.Name or "")[:50]
            ctype = child.ControlTypeName
            aid = child.AutomationId or ""
        except Exception:  # noqa: BLE001
            continue
        acc.append("%s%s | %s | AID=%s | %s" % ("  " * depth, ctype, cls, aid, name))
        walk(child, depth + 1, max_depth)


walk(win)
print("--- %d controls ---" % len(acc), flush=True)
for line in acc:
    print(line, flush=True)

mmui = [a for a in acc if "mmui::" in a]
print("--- mmui:: control count = %d ---" % len(mmui), flush=True)
