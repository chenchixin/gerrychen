---
name: wechat-takeover
description: 接管本机已登录的微信 PC 4.x 客户端并自动化操作：读会话与聊天记录、导出聊天记录、发消息/发文件、多群群发通知、群管理（置顶/免打扰）、多群监听并在被 @ 时自动回复。当用户提到「接管微信 / 微信自动回复 / 微信机器人 / 群发通知到微信群 / 导出微信聊天记录 / 私域群管理 / 微信 RPA」时使用。含 Windows 微信 4.1+「控件树被屏蔽」的处理方法与多个已验证的坑。
---

# 微信 PC 4.x 接管与自动化

面向 **Windows 10/11 + 微信 PC 4.x（Qt 版）**：在本机已登录的微信上做消息读取、导出、发送、
群管理与监听回复。**不是**微信官方接口，也不修改微信安装文件，但需要对微信进程做内存操作
（见「风险」一节，必须先向用户说明）。

---

## 一、为什么需要「热激活」

微信 4.1+ 把 `Weixin.dll` 里的 **Qt 无障碍网关字节**置 0，导致 Windows UI Automation 只能
看到一个空壳窗口（`Qt51514QWindowIcon` + 2 个节点），所有基于控件树的自动化都会失败。

**热写这一个字节**后，`mmui::` 控件树立即物化：

```
Weixin.dll+0xb135c38    0 → 1      →  mmui::MainWindow / mmui::XTableView|session_list 出现
```

该字节在微信 **重启 / 升级 / 重新登录** 后都会归零，必须重写。
**只读能力（数据库解密）不依赖它**，始终可用。

---

## 二、环境前提

| 项 | 要求 |
|---|---|
| 系统 | Windows 10/11 |
| 客户端 | 微信 PC **4.1.12+**（已在 4.1.15.13 实测） |
| Python | 3.9+，**必须 64 位** |
| 权限 | 脚本进程与微信**同级完整性**（不要用管理员运行微信、脚本用普通权限） |
| 界面 | 操作时微信窗口不能最小化（脚本会自动恢复），期间不要手动操作微信 |

若在 DSH 沙箱内运行：需要该会话处于「完全权限」，否则进程是低完整性，读不到微信控件树。

---

## 三、安装控制组件

本包脚本用「直接下载解包 wheel」的方式安装，绕过 pip 在受限环境下的临时目录问题：

```bash
python scripts/install_wheels.py wechatauto-replica
```

装好后库落在 `scripts/pylibs/`。若在普通环境，直接 `pip install wechatauto-replica` 也可以。

依赖以 `wechatauto-replica` 为准（Apache-2.0）。`pyautogui` 在 PyPI 只有源码包，
仅「朋友圈互动」需要，缺失不影响消息功能。

---

## 四、每次使用的固定流程

### 1. 确认账号（多账号机器必做）

```bash
python scripts/wxops.py sessions
```

自动化**只作用于当前登录的那个账号**：界面操作走登录中的客户端，数据库绑定也跟随它。
多账号机器上数据目录里会有多个 `wxid_*` 目录，别搞错对象再群发。

### 2. 需要界面操作时，热激活控件树

```bash
python scripts/activate_tree.py
```

成功标志：`is_materialized -> True`，且 `main_class` 为 `mmui::MainWindow`。

### 3. 执行操作

见下一节。

---

## 五、命令速查（scripts/wxops.py）

```bash
# 列出会话（先确认账号）
python scripts/wxops.py sessions

# 导出聊天记录为 UTF-8 文本（只读，最安全）
python scripts/wxops.py export 文件传输助手 --limit 500 --out D:\导出\a.txt

# 发消息 / 发文件（发送后自动从数据库回读验证）
python scripts/wxops.py send --to 文件传输助手 --text "内容"
python scripts/wxops.py send --to 会话名 --file D:\报告.pdf

# 群发：默认只预览，必须显式加 --send 才真发；目标之间自动加延迟
python scripts/wxops.py broadcast --targets "群A,群B" --text "通知"
python scripts/wxops.py broadcast --targets "群A,群B" --text "通知" --send

# 群管理：置顶 / 免打扰（开关都是双向的）
python scripts/wxops.py admin --chat 群名 --mute on
python scripts/wxops.py admin --chat 群名 --mute off
python scripts/wxops.py admin --chat 群名 --pin on

# 监听：默认「仅被 @ 时回复」
python scripts/wxops.py watch --all --reply "您好，收到，稍后回复您" --at-name 你的群昵称
python scripts/wxops.py watch --chats "群A,群B" --reply "收到：{text}"
```

`--reply` 支持 `{text}`（对方原文）与 `{sender}`（发送人）。
危险开关 `--allow-ocr-fallback`：控件树不可用时退化为 OCR/坐标路径，**有误发到错误窗口的风险**，
默认关闭（宁可拒绝执行）。

群公告（announcement）**库未实现**，需要自行补 UI 逻辑。

---

## 六、安全设计（默认已内置，改动前请理解）

1. **窗口白名单校验**：只认「Qt 窗口类 + 所属进程确实是 `Weixin.exe`/`WeChat.exe`」的窗口。
   只按标题含「微信」认窗口是危险的——别的程序（例如 AI 客户端界面）标题里也可能含「微信」，
   会被误判成微信窗口并把文字打进去。**本机实际触发过**。
2. **发送前再次校验控件树**：长期运行的监听器若遇到微信重启（字节归零），
   会拒绝回复而不是退化成 OCR 去猜窗口。
3. **回读验证**：发送后等数据库出现新消息才判定成功。库自带的 `--verify` 会误报
   （数据库写入有延迟），不要依赖它。
4. **防死循环**：库里「自己发的消息」判据是硬编码的 `sender_id == 2`，在部分机器上
   自己的 rowid 是 1，于是**它把自己发的消息当成别人发的**。因此必须自己挡：
   「回声守卫」（内容与自己刚发的回复完全相同则忽略）+「频率守卫」（同会话最小间隔）
   + 默认「仅被 @ 时回复」。
5. **群发默认只预览**，必须显式 `--send`。

---

## 七、已知坑（实测，按踩到频率排序）

| 现象 | 原因 / 处理 |
|---|---|
| **群里回复卡住、永远发不出去** | 群**没有自定义群名**时数据库里只有群号（`xxx@chatroom`），而微信搜索框只认显示名 → 拿群号去搜会一路重试到卡死。用「数据库会话摘要 ↔ 界面会话列表预览文本」反查显示名（`wxops.resolve_display_name`） |
| `send --verify` 报「数据库未确认」 | **误报**，写入有延迟。用回读新消息的方式验证 |
| 控件树突然「拿不到」 | 多半是**库把微信窗口最小化了**（最小化时 UIA 扫不到子控件）。先恢复窗口再判断 |
| `EnumProcessModulesEx` 返回 `err=5 拒绝访问` | 安全软件或客户端保护拦了模块枚举 → **无法热写网关字节**。把 Python 加入白名单 / 退出安全软件 / 重启微信后立刻激活 |
| 免打扰只能开不能关 | 库只有「消息免打扰」键，没有「取消消息免打扰」。要点原始菜单项（`select_option`） |
| 自动回复自己触发自己 | 见「安全设计」第 4 条 |
| 发送后微信窗口被最小化 | 库的隐私设计（正常行为），下次操作前恢复即可 |
| 聊天记录拿不到发送者姓名 | 微信 4.x 的 UI/库限制，部分会话 `sender_username` 为空（此时靠 `sender_id` 区分自己/他人） |
| 图片下载失败 | 图片密钥按账号缓存，且需在微信里**点开任意一张图**后才会拿到 |

---

## 八、诊断脚本

| 脚本 | 用途 |
|---|---|
| `scripts/diag_access.py` | 进程权限与模块枚举诊断（判断能否热激活） |
| `scripts/dump_tree.py` | 打印真实控件树（判断是空壳还是已物化） |
| `scripts/resolve_group_name.py` | 群号 ↔ 界面显示名 对照 |
| `scripts/list_groups.py` | 群列表与成员数（只读） |
| `scripts/diag_self.py` | 检查「自己发的消息」在库里的判据 |

---

## 九、风险（必须先告知用户）

1. 本方案会在**运行中的微信进程内存里改写 1 个字节**，并**扫描进程内存提取数据库密钥**。
   不修改微信安装文件与磁盘数据，但比纯 UI 点击激进得多，可能触发客户端保护
   （表现为模块枚举被拒）或安全软件拦截。
2. **账号风控风险**：控制发送频率、目标之间加延迟、不要高频群发营销内容；
   建议先用非核心账号或小范围验证。
3. 社区反馈显示微信可能对账号做评估并限制其 UIA 暴露（换账号后才可见）。
4. 使用后果由使用者自行承担。
