"""只读检查：群列表与成员读取能力（用于确认群管理路径可用）。"""
import wxenv  # noqa: F401

from wechatauto import WeChatDB

db = WeChatDB()
groups = db.get_groups()
print("群总数:", len(groups))
for g in groups[:5]:
    name = g.get("name") or g.get("username")
    members = db.get_group_members(g.get("username"))
    print("  %-28s 成员 %d" % (name, len(members)))
print("--- 联系人检索能力 ---")
hits = db.search_contact("陈")
print("搜索『陈』命中:", len(hits))
